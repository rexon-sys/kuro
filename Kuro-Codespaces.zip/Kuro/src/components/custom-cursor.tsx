"use client";

import { useEffect } from "react";

export default function CustomCursor() {
  useEffect(() => {
    const finePointer = window.matchMedia("(pointer: fine)").matches;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!finePointer || reducedMotion) return;

    const dot = document.querySelector<HTMLElement>("[data-kuro-cursor-dot]");
    const ring = document.querySelector<HTMLElement>("[data-kuro-cursor-ring]");
    if (!dot || !ring) return;

    document.body.classList.add("kuro-cursor-active");
    let frame = 0;
    let x = -100;
    let y = -100;

    const move = (event: MouseEvent) => {
      x = event.clientX;
      y = event.clientY;
      if (frame) cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        dot.style.transform = `translate3d(${x}px, ${y}px, 0) translate(-50%, -50%)`;
        ring.style.transform = `translate3d(${x}px, ${y}px, 0) translate(-50%, -50%)`;
      });
    };

    const down = () => document.body.classList.add("kuro-cursor-down");
    const up = () => document.body.classList.remove("kuro-cursor-down");
    const over = (event: Event) => {
      const target = event.target as HTMLElement | null;
      const interactive = target?.closest("a, button, [role='button'], [data-cursor='hover']");
      document.body.classList.toggle("kuro-cursor-hover", Boolean(interactive));
      document.body.classList.toggle("kuro-cursor-native", Boolean(target?.closest("input, textarea, [contenteditable='true'], .artplayer, .artplayer-app, video")));
    };

    window.addEventListener("mousemove", move, { passive: true });
    window.addEventListener("mousedown", down);
    window.addEventListener("mouseup", up);
    document.addEventListener("mouseover", over, { passive: true });

    return () => {
      document.body.classList.remove("kuro-cursor-active", "kuro-cursor-down", "kuro-cursor-hover", "kuro-cursor-native");
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mousedown", down);
      window.removeEventListener("mouseup", up);
      document.removeEventListener("mouseover", over);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <>
      <span aria-hidden="true" data-kuro-cursor-ring className="kuro-cursor-ring" />
      <span aria-hidden="true" data-kuro-cursor-dot className="kuro-cursor-dot" />
    </>
  );
}
